/**
 * Seed script — populates the local Supabase with dev data.
 * Run with: `pnpm db:seed`
 *
 * Creates:
 *   · 3 stores (Selangor Central, KL Bangsar, Penang Georgetown)
 *   · 5 users (one per role, all with password `curiouser123`)
 *   · User-store memberships
 *   · Sample classes + children
 *   · Sample class themes + plans
 *   · Sample courses
 *   · Sample SOP templates
 */

import { createClient } from '@supabase/supabase-js';

const admin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
  { auth: { persistSession: false, autoRefreshToken: false } }
);

const USERS = [
  { email: 'hq@curiouser.co',      fullName: 'Priya Ramesh', role: 'HQ_ADMIN'         },
  { email: 'sarah@curiouser.co',   fullName: 'Sarah Chen',   role: 'FRANCHISEE_ADMIN' },
  { email: 'james@curiouser.co',   fullName: 'James Tan',    role: 'FRANCHISEE_ADMIN' },
  { email: 'maya@curiouser.co',    fullName: 'Maya Lee',     role: 'TEACHER'          },
  { email: 'daniel@curiouser.co',  fullName: 'Daniel Wong',  role: 'TEACHER'          },
] as const;

async function main() {
  console.log('Seeding stores…');
  const { data: stores } = await admin.from('stores').insert([
    { code: '#047', name: 'Selangor Central',  region: 'Selangor' },
    { code: '#048', name: 'KL Bangsar',        region: 'KL'       },
    { code: '#052', name: 'Penang Georgetown', region: 'Penang'   },
  ]).select();
  if (!stores) throw new Error('Failed to create stores');

  console.log('Seeding users…');
  const userIds: Record<string, string> = {};
  for (const u of USERS) {
    const { data, error } = await admin.auth.admin.createUser({
      email: u.email,
      password: 'curiouser123',
      email_confirm: true,
      user_metadata: { full_name: u.fullName, role: u.role },
    });
    if (error) { console.error(`  ✗ ${u.email}:`, error.message); continue; }
    userIds[u.email] = data.user.id;
    console.log(`  ✓ ${u.email} (${u.role})`);
  }

  console.log('Linking users to stores…');
  const selangor = stores.find((s) => s.code === '#047')!;
  const bangsar  = stores.find((s) => s.code === '#048')!;

  await admin.from('user_store_relationship').insert([
    { user_id: userIds['sarah@curiouser.co'],  store_id: selangor.id, role_at_store: 'FRANCHISEE_ADMIN', is_primary: true },
    { user_id: userIds['maya@curiouser.co'],   store_id: selangor.id, role_at_store: 'TEACHER',          is_primary: true },
    { user_id: userIds['daniel@curiouser.co'], store_id: selangor.id, role_at_store: 'TEACHER',          is_primary: true },
    { user_id: userIds['james@curiouser.co'],  store_id: bangsar.id,  role_at_store: 'FRANCHISEE_ADMIN', is_primary: true },
  ]);

  console.log('Seeding classes at Selangor…');
  const { data: classes } = await admin.from('classes').insert([
    { store_id: selangor.id, name: 'Explorers',  age_group: '3-4' },
    { store_id: selangor.id, name: 'Adventurers', age_group: '4-5' },
    { store_id: selangor.id, name: 'Innovators',  age_group: '5-6' },
  ]).select();
  if (!classes) throw new Error('Failed to create classes');

  await admin.from('teacher_class_assignments').insert([
    { teacher_id: userIds['maya@curiouser.co'],   class_id: classes[0].id },
    { teacher_id: userIds['maya@curiouser.co'],   class_id: classes[1].id },
    { teacher_id: userIds['daniel@curiouser.co'], class_id: classes[2].id },
  ]);

  console.log('Seeding children…');
  await admin.from('children').insert([
    { store_id: selangor.id, class_id: classes[1].id, full_name: 'Maya Patel',     date_of_birth: '2021-01-15' },
    { store_id: selangor.id, class_id: classes[1].id, full_name: 'Liam O\'Connor', date_of_birth: '2020-08-03' },
    { store_id: selangor.id, class_id: classes[0].id, full_name: 'Amira Hassan',   date_of_birth: '2021-05-22' },
  ]);

  console.log('Seeding class themes…');
  await admin.from('class_themes').insert([
    { slug: 'drama',  name: 'Drama',            description: 'Roleplay, storytelling, puppetry', display_order: 1 },
    { slug: 'music',  name: 'Music & Movement', description: 'Rhythm, song, instruments',        display_order: 2 },
    { slug: 'stem',   name: 'STEM',             description: 'Discovery, experiments',           display_order: 3 },
    { slug: 'nature', name: 'Nature',           description: 'Plants, animals, ecology',         display_order: 4 },
    { slug: 'art',    name: 'Creative Arts',    description: 'Paint, craft, sculpture',          display_order: 5 },
    { slug: 'story',  name: 'Storytime',        description: 'Books, language, imagination',     display_order: 6 },
  ]);

  console.log('\n✓ Seed complete. Log in with any of:');
  USERS.forEach((u) => console.log(`    ${u.email.padEnd(26)} / curiouser123  (${u.role})`));
}

main().catch((err) => { console.error('Seed failed:', err); process.exit(1); });
