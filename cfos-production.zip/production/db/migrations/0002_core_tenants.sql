-- ═══════════════════════════════════════════════════════════════
-- 0002_core_tenants.sql — Users, stores, roles, memberships
-- ═══════════════════════════════════════════════════════════════

-- Stores (franchise locations)
CREATE TABLE stores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  region TEXT,
  timezone TEXT DEFAULT 'Asia/Kuala_Lumpur',
  contract_start DATE,
  status store_status DEFAULT 'active',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_stores_status ON stores(status);

-- Profiles (extends Supabase auth.users 1-to-1)
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  avatar_url TEXT,
  phone TEXT,
  role app_role NOT NULL DEFAULT 'TEACHER',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  last_login_at TIMESTAMPTZ
);

CREATE INDEX idx_profiles_role ON profiles(role);
CREATE INDEX idx_profiles_active ON profiles(is_active) WHERE is_active = true;

-- user_store_relationship: many-to-many
--   A FRANCHISEE_ADMIN can own multiple stores.
--   A TEACHER is usually at one store, but can be assigned to more.
CREATE TABLE user_store_relationship (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  role_at_store app_role NOT NULL,
  is_primary BOOLEAN DEFAULT false,
  assigned_at TIMESTAMPTZ DEFAULT now(),
  assigned_by UUID REFERENCES profiles(id),
  UNIQUE (user_id, store_id)
);

CREATE INDEX idx_usr_user ON user_store_relationship(user_id);
CREATE INDEX idx_usr_store ON user_store_relationship(store_id);

-- Classes (groups of children at a store)
CREATE TABLE classes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  age_group TEXT,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_classes_store ON classes(store_id);

-- Teacher <-> class assignments
CREATE TABLE teacher_class_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  class_id UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  assigned_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE (teacher_id, class_id)
);

-- Children
CREATE TABLE children (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  class_id UUID REFERENCES classes(id) ON DELETE SET NULL,
  full_name TEXT NOT NULL,
  date_of_birth DATE NOT NULL,
  enrolled_at DATE DEFAULT CURRENT_DATE,
  withdrawn_at DATE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_children_store ON children(store_id);
CREATE INDEX idx_children_class ON children(class_id);

-- Parent <-> child link (role=PARENT users)
CREATE TABLE parent_child_relationship (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
  relationship TEXT,
  can_receive_reports BOOLEAN DEFAULT true,
  UNIQUE (parent_id, child_id)
);

-- Trigger: auto-create profile row when auth.users is created
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    COALESCE((NEW.raw_user_meta_data->>'role')::app_role, 'TEACHER'::app_role)
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Helper: get current user's role (for RLS policies)
CREATE OR REPLACE FUNCTION current_user_role()
RETURNS app_role
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public AS $$
  SELECT role FROM profiles WHERE id = auth.uid();
$$;

-- Helper: get store IDs the current user belongs to
CREATE OR REPLACE FUNCTION current_user_store_ids()
RETURNS SETOF UUID
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public AS $$
  SELECT store_id FROM user_store_relationship WHERE user_id = auth.uid();
$$;
