-- ═══════════════════════════════════════════════════════════════
-- 0007_rls_policies.sql — Row-Level Security
-- ═══════════════════════════════════════════════════════════════
-- This is the heart of multi-tenancy. Every tenant-scoped table has RLS
-- enforcing:
--   · HQ_ADMIN         → sees everything
--   · FRANCHISEE_ADMIN → sees only their stores (via user_store_relationship)
--   · TEACHER          → sees only their store's data AND their assigned classes
--   · PARENT           → sees only their own child's data
--
-- All policies use the SECURITY DEFINER helpers from 0002_core_tenants.sql:
--   · current_user_role()       → returns the caller's app_role
--   · current_user_store_ids()  → returns UUIDs of stores they belong to
-- ═══════════════════════════════════════════════════════════════

-- ─── ENABLE RLS ON ALL TENANT-SCOPED TABLES ───
ALTER TABLE stores                      ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles                    ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_store_relationship     ENABLE ROW LEVEL SECURITY;
ALTER TABLE classes                     ENABLE ROW LEVEL SECURITY;
ALTER TABLE teacher_class_assignments   ENABLE ROW LEVEL SECURITY;
ALTER TABLE children                    ENABLE ROW LEVEL SECURITY;
ALTER TABLE parent_child_relationship   ENABLE ROW LEVEL SECURITY;
ALTER TABLE observations                ENABLE ROW LEVEL SECURITY;
ALTER TABLE reports                     ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_sections             ENABLE ROW LEVEL SECURITY;
ALTER TABLE sop_executions              ENABLE ROW LEVEL SECURITY;
ALTER TABLE sop_execution_steps         ENABLE ROW LEVEL SECURITY;
ALTER TABLE sop_execution_photos        ENABLE ROW LEVEL SECURITY;
ALTER TABLE class_plan_views            ENABLE ROW LEVEL SECURITY;

-- Curriculum / course content is read-by-all-authenticated, managed by HQ
ALTER TABLE class_themes          ENABLE ROW LEVEL SECURITY;
ALTER TABLE class_plan_folders    ENABLE ROW LEVEL SECURITY;
ALTER TABLE class_plans           ENABLE ROW LEVEL SECURITY;
ALTER TABLE courses               ENABLE ROW LEVEL SECURITY;
ALTER TABLE modules               ENABLE ROW LEVEL SECURITY;
ALTER TABLE lessons               ENABLE ROW LEVEL SECURITY;
ALTER TABLE enrollments           ENABLE ROW LEVEL SECURITY;
ALTER TABLE lesson_progress       ENABLE ROW LEVEL SECURITY;
ALTER TABLE certificates          ENABLE ROW LEVEL SECURITY;
ALTER TABLE sop_templates         ENABLE ROW LEVEL SECURITY;

-- ═══════════════════════════════════════════════════════════════
-- STORES
-- ═══════════════════════════════════════════════════════════════

-- HQ_ADMIN can see and manage all stores
CREATE POLICY "stores: HQ all access"
  ON stores FOR ALL
  USING (current_user_role() = 'HQ_ADMIN');

-- Everyone else can read the stores they belong to
CREATE POLICY "stores: read own"
  ON stores FOR SELECT
  USING (id IN (SELECT current_user_store_ids()));

-- ═══════════════════════════════════════════════════════════════
-- PROFILES
-- ═══════════════════════════════════════════════════════════════

-- Every authenticated user can read their own profile
CREATE POLICY "profiles: read own"
  ON profiles FOR SELECT
  USING (id = auth.uid());

-- HQ_ADMIN can read all profiles
CREATE POLICY "profiles: HQ read all"
  ON profiles FOR SELECT
  USING (current_user_role() = 'HQ_ADMIN');

-- FRANCHISEE_ADMIN can read profiles of users at their stores
CREATE POLICY "profiles: franchisee read own-store users"
  ON profiles FOR SELECT
  USING (
    current_user_role() = 'FRANCHISEE_ADMIN'
    AND id IN (
      SELECT user_id FROM user_store_relationship
      WHERE store_id IN (SELECT current_user_store_ids())
    )
  );

-- Users can update their own profile (name, avatar, phone only — not role!)
CREATE POLICY "profiles: update own"
  ON profiles FOR UPDATE
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid() AND role = (SELECT role FROM profiles WHERE id = auth.uid()));

-- HQ_ADMIN can update any profile (including role)
CREATE POLICY "profiles: HQ update all"
  ON profiles FOR UPDATE
  USING (current_user_role() = 'HQ_ADMIN');

-- ═══════════════════════════════════════════════════════════════
-- USER_STORE_RELATIONSHIP
-- ═══════════════════════════════════════════════════════════════

CREATE POLICY "usr: HQ all access"
  ON user_store_relationship FOR ALL
  USING (current_user_role() = 'HQ_ADMIN');

CREATE POLICY "usr: read own"
  ON user_store_relationship FOR SELECT
  USING (user_id = auth.uid());

-- FRANCHISEE_ADMIN can manage memberships at their stores
CREATE POLICY "usr: franchisee manage own-store"
  ON user_store_relationship FOR ALL
  USING (
    current_user_role() = 'FRANCHISEE_ADMIN'
    AND store_id IN (SELECT current_user_store_ids())
  );

-- ═══════════════════════════════════════════════════════════════
-- CLASSES
-- ═══════════════════════════════════════════════════════════════

CREATE POLICY "classes: HQ all"
  ON classes FOR ALL
  USING (current_user_role() = 'HQ_ADMIN');

CREATE POLICY "classes: franchisee own-store"
  ON classes FOR ALL
  USING (
    current_user_role() = 'FRANCHISEE_ADMIN'
    AND store_id IN (SELECT current_user_store_ids())
  );

-- TEACHER sees classes at their store (read only for list; assigned classes for write)
CREATE POLICY "classes: teacher read own-store"
  ON classes FOR SELECT
  USING (
    current_user_role() = 'TEACHER'
    AND store_id IN (SELECT current_user_store_ids())
  );

-- ═══════════════════════════════════════════════════════════════
-- CHILDREN
-- ═══════════════════════════════════════════════════════════════

CREATE POLICY "children: HQ all"
  ON children FOR ALL
  USING (current_user_role() = 'HQ_ADMIN');

CREATE POLICY "children: franchisee own-store"
  ON children FOR ALL
  USING (
    current_user_role() = 'FRANCHISEE_ADMIN'
    AND store_id IN (SELECT current_user_store_ids())
  );

-- TEACHER: only children in classes they're assigned to
CREATE POLICY "children: teacher assigned classes"
  ON children FOR SELECT
  USING (
    current_user_role() = 'TEACHER'
    AND class_id IN (
      SELECT class_id FROM teacher_class_assignments WHERE teacher_id = auth.uid()
    )
  );

-- PARENT: only their own children
CREATE POLICY "children: parent own"
  ON children FOR SELECT
  USING (
    current_user_role() = 'PARENT'
    AND id IN (
      SELECT child_id FROM parent_child_relationship WHERE parent_id = auth.uid()
    )
  );

-- ═══════════════════════════════════════════════════════════════
-- OBSERVATIONS
-- ═══════════════════════════════════════════════════════════════

CREATE POLICY "obs: HQ all"
  ON observations FOR ALL
  USING (current_user_role() = 'HQ_ADMIN');

-- FRANCHISEE_ADMIN: observations on children at their stores
CREATE POLICY "obs: franchisee own-store"
  ON observations FOR ALL
  USING (
    current_user_role() = 'FRANCHISEE_ADMIN'
    AND child_id IN (
      SELECT id FROM children WHERE store_id IN (SELECT current_user_store_ids())
    )
  );

-- TEACHER: can CREATE observations on children in their assigned classes
CREATE POLICY "obs: teacher create own-class"
  ON observations FOR INSERT
  WITH CHECK (
    current_user_role() = 'TEACHER'
    AND teacher_id = auth.uid()
    AND child_id IN (
      SELECT c.id FROM children c
      JOIN teacher_class_assignments tca ON tca.class_id = c.class_id
      WHERE tca.teacher_id = auth.uid()
    )
  );

-- TEACHER can read their own observations, and any observation for children in their classes
CREATE POLICY "obs: teacher read"
  ON observations FOR SELECT
  USING (
    current_user_role() = 'TEACHER'
    AND (
      teacher_id = auth.uid()
      OR child_id IN (
        SELECT c.id FROM children c
        JOIN teacher_class_assignments tca ON tca.class_id = c.class_id
        WHERE tca.teacher_id = auth.uid()
      )
    )
  );

-- TEACHER can update/delete only their own observations
CREATE POLICY "obs: teacher update own"
  ON observations FOR UPDATE
  USING (teacher_id = auth.uid());

CREATE POLICY "obs: teacher delete own"
  ON observations FOR DELETE
  USING (teacher_id = auth.uid());

-- PARENT: read-only access to observations on their own children
CREATE POLICY "obs: parent read own-child"
  ON observations FOR SELECT
  USING (
    current_user_role() = 'PARENT'
    AND child_id IN (
      SELECT child_id FROM parent_child_relationship
      WHERE parent_id = auth.uid() AND can_receive_reports = true
    )
  );

-- ═══════════════════════════════════════════════════════════════
-- REPORTS
-- ═══════════════════════════════════════════════════════════════

CREATE POLICY "reports: HQ all"
  ON reports FOR ALL
  USING (current_user_role() = 'HQ_ADMIN');

CREATE POLICY "reports: franchisee own-store"
  ON reports FOR ALL
  USING (
    current_user_role() = 'FRANCHISEE_ADMIN'
    AND child_id IN (
      SELECT id FROM children WHERE store_id IN (SELECT current_user_store_ids())
    )
  );

CREATE POLICY "reports: teacher read"
  ON reports FOR SELECT
  USING (
    current_user_role() = 'TEACHER'
    AND child_id IN (
      SELECT c.id FROM children c
      JOIN teacher_class_assignments tca ON tca.class_id = c.class_id
      WHERE tca.teacher_id = auth.uid()
    )
  );

CREATE POLICY "reports: parent read sent"
  ON reports FOR SELECT
  USING (
    current_user_role() = 'PARENT'
    AND status = 'sent'
    AND child_id IN (
      SELECT child_id FROM parent_child_relationship
      WHERE parent_id = auth.uid() AND can_receive_reports = true
    )
  );

CREATE POLICY "report_sections: inherit from reports"
  ON report_sections FOR ALL
  USING (report_id IN (SELECT id FROM reports));

-- ═══════════════════════════════════════════════════════════════
-- SOP EXECUTIONS
-- ═══════════════════════════════════════════════════════════════

CREATE POLICY "sop_exec: HQ all"
  ON sop_executions FOR ALL
  USING (current_user_role() = 'HQ_ADMIN');

CREATE POLICY "sop_exec: franchisee own-store"
  ON sop_executions FOR ALL
  USING (
    current_user_role() = 'FRANCHISEE_ADMIN'
    AND store_id IN (SELECT current_user_store_ids())
  );

CREATE POLICY "sop_exec: teacher own"
  ON sop_executions FOR ALL
  USING (
    current_user_role() = 'TEACHER'
    AND teacher_id = auth.uid()
  );

CREATE POLICY "sop_exec_steps: inherit"
  ON sop_execution_steps FOR ALL
  USING (execution_id IN (SELECT id FROM sop_executions));

CREATE POLICY "sop_exec_photos: inherit"
  ON sop_execution_photos FOR ALL
  USING (execution_step_id IN (SELECT id FROM sop_execution_steps));

-- ═══════════════════════════════════════════════════════════════
-- CURRICULUM / COURSES (HQ manages, everyone reads published)
-- ═══════════════════════════════════════════════════════════════

CREATE POLICY "themes: all read published" ON class_themes FOR SELECT USING (active = true);
CREATE POLICY "themes: HQ write"           ON class_themes FOR ALL    USING (current_user_role() = 'HQ_ADMIN');

CREATE POLICY "folders: all read"  ON class_plan_folders FOR SELECT USING (true);
CREATE POLICY "folders: HQ write"  ON class_plan_folders FOR ALL    USING (current_user_role() = 'HQ_ADMIN');

-- Plans: everyone reads published; HQ writes
CREATE POLICY "plans: all read published" ON class_plans FOR SELECT USING (status = 'published');
CREATE POLICY "plans: HQ all"             ON class_plans FOR ALL    USING (current_user_role() = 'HQ_ADMIN');

-- Every view is logged (no one reads except HQ for audit)
CREATE POLICY "views: insert own"  ON class_plan_views FOR INSERT WITH CHECK (user_id = auth.uid());
CREATE POLICY "views: HQ read all" ON class_plan_views FOR SELECT USING (current_user_role() = 'HQ_ADMIN');

-- Courses & training
CREATE POLICY "courses: all read published" ON courses FOR SELECT USING (status = 'published');
CREATE POLICY "courses: HQ write"           ON courses FOR ALL    USING (current_user_role() = 'HQ_ADMIN');

CREATE POLICY "modules: all read" ON modules FOR SELECT USING (true);
CREATE POLICY "modules: HQ write" ON modules FOR ALL    USING (current_user_role() = 'HQ_ADMIN');

CREATE POLICY "lessons: all read" ON lessons FOR SELECT USING (true);
CREATE POLICY "lessons: HQ write" ON lessons FOR ALL    USING (current_user_role() = 'HQ_ADMIN');

-- Enrollments / progress / certs — users own their data
CREATE POLICY "enrollments: own" ON enrollments FOR ALL USING (user_id = auth.uid());
CREATE POLICY "enrollments: HQ read all" ON enrollments FOR SELECT USING (current_user_role() = 'HQ_ADMIN');
CREATE POLICY "enrollments: franchisee read own-store teachers" ON enrollments FOR SELECT USING (
  current_user_role() = 'FRANCHISEE_ADMIN'
  AND user_id IN (
    SELECT user_id FROM user_store_relationship
    WHERE store_id IN (SELECT current_user_store_ids())
  )
);

CREATE POLICY "lesson_progress: own" ON lesson_progress FOR ALL USING (
  enrollment_id IN (SELECT id FROM enrollments WHERE user_id = auth.uid())
);

CREATE POLICY "certs: own"         ON certificates FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "certs: HQ read all" ON certificates FOR SELECT USING (current_user_role() = 'HQ_ADMIN');

CREATE POLICY "sop_templates: all read published" ON sop_templates FOR SELECT USING (status = 'published');
CREATE POLICY "sop_templates: HQ write"           ON sop_templates FOR ALL    USING (current_user_role() = 'HQ_ADMIN');
