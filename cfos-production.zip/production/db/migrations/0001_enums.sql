-- ═══════════════════════════════════════════════════════════════
-- 0001_enums.sql — Enumerated types
-- ═══════════════════════════════════════════════════════════════

CREATE TYPE app_role AS ENUM (
  'HQ_ADMIN',
  'FRANCHISEE_ADMIN',
  'TEACHER',
  'PARENT'
);

CREATE TYPE store_status AS ENUM ('active', 'suspended', 'closed');

CREATE TYPE content_status AS ENUM ('draft', 'published', 'archived');

CREATE TYPE enrollment_status AS ENUM ('in_progress', 'completed', 'expired');

CREATE TYPE lesson_type AS ENUM ('video', 'slides', 'quiz', 'reading');

CREATE TYPE lesson_status AS ENUM ('not_started', 'in_progress', 'completed');

CREATE TYPE sop_execution_status AS ENUM ('in_progress', 'completed', 'abandoned');

CREATE TYPE eyfs_area AS ENUM (
  'communication_language',
  'physical_development',
  'personal_social_emotional',
  'literacy',
  'mathematics',
  'understanding_world',
  'expressive_arts_design'
);
