-- ═══════════════════════════════════════════════════════════════
-- 0003_class_plans.sql — IP-protected curriculum
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE class_themes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  display_order INT DEFAULT 0,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE class_plan_folders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  theme_id UUID NOT NULL REFERENCES class_themes(id) ON DELETE CASCADE,
  year INT NOT NULL,
  month INT NOT NULL CHECK (month BETWEEN 1 AND 12),
  week_of_month INT NOT NULL CHECK (week_of_month BETWEEN 1 AND 5),
  UNIQUE (theme_id, year, month, week_of_month)
);

CREATE INDEX idx_folders_theme_date ON class_plan_folders(theme_id, year, month);

CREATE TABLE class_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  folder_id UUID NOT NULL REFERENCES class_plan_folders(id) ON DELETE CASCADE,
  lesson_number INT NOT NULL,
  title TEXT NOT NULL,
  overview TEXT,
  age_group TEXT,
  duration_minutes INT,
  storage_key TEXT NOT NULL,
  required_course_id UUID,  -- FK added in 0004 (circular)
  status content_status DEFAULT 'draft',
  published_at TIMESTAMPTZ,
  created_by UUID REFERENCES profiles(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_plans_folder ON class_plans(folder_id);
CREATE INDEX idx_plans_status ON class_plans(status);

-- Audit: every view is logged (IP protection)
CREATE TABLE class_plan_views (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id UUID NOT NULL REFERENCES class_plans(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id),
  ip_address INET,
  user_agent TEXT,
  session_duration_seconds INT,
  pages_viewed INT[],
  viewed_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_views_plan_time ON class_plan_views(plan_id, viewed_at DESC);

-- Security events (right-click, copy attempts, etc.)
CREATE TABLE class_plan_security_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id UUID REFERENCES class_plans(id) ON DELETE SET NULL,
  user_id UUID REFERENCES profiles(id),
  event_type TEXT NOT NULL,
  metadata JSONB,
  occurred_at TIMESTAMPTZ DEFAULT now()
);


-- ═══════════════════════════════════════════════════════════════
-- 0004_training.sql — Training Academy LMS
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  subtitle TEXT,
  description TEXT,
  cover_image_url TEXT,
  level TEXT,
  total_hours NUMERIC(4,2),
  instructor_name TEXT,
  is_required BOOLEAN DEFAULT false,
  required_for_roles app_role[],
  pass_threshold NUMERIC(3,2) DEFAULT 0.70,
  status content_status DEFAULT 'draft',
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Now add the FK from class_plans back to courses
ALTER TABLE class_plans
  ADD CONSTRAINT fk_class_plans_required_course
  FOREIGN KEY (required_course_id) REFERENCES courses(id);

CREATE TABLE modules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  display_order INT NOT NULL,
  UNIQUE (course_id, display_order)
);

CREATE TABLE lessons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  module_id UUID NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  display_order INT NOT NULL,
  lesson_type lesson_type NOT NULL,
  duration_minutes INT,
  video_url TEXT,
  slides_url TEXT,
  content_body TEXT,
  UNIQUE (module_id, display_order)
);

CREATE TABLE lesson_resources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lesson_id UUID NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  title TEXT,
  file_url TEXT,
  file_type TEXT,
  file_size_bytes BIGINT
);

CREATE TABLE quizzes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lesson_id UUID NOT NULL REFERENCES lessons(id) ON DELETE CASCADE UNIQUE,
  title TEXT,
  pass_threshold NUMERIC(3,2) DEFAULT 0.70,
  max_attempts INT DEFAULT 3
);

CREATE TABLE quiz_questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  quiz_id UUID NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  display_order INT,
  options JSONB NOT NULL,
  correct_option_ids TEXT[] NOT NULL,
  explanation TEXT,
  points INT DEFAULT 1
);

CREATE TABLE enrollments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  enrolled_at TIMESTAMPTZ DEFAULT now(),
  last_accessed_at TIMESTAMPTZ,
  progress_percent INT DEFAULT 0,
  status enrollment_status DEFAULT 'in_progress',
  completed_at TIMESTAMPTZ,
  UNIQUE (user_id, course_id)
);

CREATE INDEX idx_enrollments_user ON enrollments(user_id);

CREATE TABLE lesson_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  enrollment_id UUID NOT NULL REFERENCES enrollments(id) ON DELETE CASCADE,
  lesson_id UUID NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  status lesson_status DEFAULT 'not_started',
  progress_percent INT DEFAULT 0,
  time_spent_seconds INT DEFAULT 0,
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  UNIQUE (enrollment_id, lesson_id)
);

CREATE TABLE quiz_attempts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  quiz_id UUID NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
  attempt_number INT NOT NULL,
  started_at TIMESTAMPTZ DEFAULT now(),
  submitted_at TIMESTAMPTZ,
  score NUMERIC(5,2),
  passed BOOLEAN,
  answers JSONB
);

CREATE TABLE certificates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  serial TEXT UNIQUE NOT NULL,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  issued_at TIMESTAMPTZ DEFAULT now(),
  pdf_url TEXT,
  verification_url TEXT
);


-- ═══════════════════════════════════════════════════════════════
-- 0005_sops.sql — SOP Execution
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE sop_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  linked_class_plan_id UUID REFERENCES class_plans(id) ON DELETE SET NULL,
  linked_theme_id UUID REFERENCES class_themes(id) ON DELETE SET NULL,
  duration_minutes INT,
  version INT DEFAULT 1,
  status content_status DEFAULT 'draft',
  published_at TIMESTAMPTZ,
  created_by UUID REFERENCES profiles(id),
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE sop_materials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id UUID NOT NULL REFERENCES sop_templates(id) ON DELETE CASCADE,
  label TEXT NOT NULL,
  quantity TEXT,
  display_order INT
);

CREATE TABLE sop_steps (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id UUID NOT NULL REFERENCES sop_templates(id) ON DELETE CASCADE,
  display_order INT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  estimated_time TEXT,
  requires_photo BOOLEAN DEFAULT false,
  photo_prompt TEXT,
  reference_image_url TEXT,
  UNIQUE (template_id, display_order)
);

CREATE TABLE sop_executions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id UUID NOT NULL REFERENCES sop_templates(id),
  template_version INT NOT NULL,
  teacher_id UUID NOT NULL REFERENCES profiles(id),
  store_id UUID NOT NULL REFERENCES stores(id),
  class_id UUID REFERENCES classes(id),
  class_plan_id UUID REFERENCES class_plans(id),
  session_date DATE NOT NULL,
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  status sop_execution_status DEFAULT 'in_progress',
  steps_completed INT DEFAULT 0,
  total_steps INT NOT NULL,
  completion_percent INT DEFAULT 0,
  overall_notes TEXT
);

CREATE INDEX idx_sop_exec_store_date ON sop_executions(store_id, session_date DESC);
CREATE INDEX idx_sop_exec_teacher ON sop_executions(teacher_id);

CREATE TABLE sop_execution_steps (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  execution_id UUID NOT NULL REFERENCES sop_executions(id) ON DELETE CASCADE,
  step_id UUID NOT NULL REFERENCES sop_steps(id),
  completed BOOLEAN DEFAULT false,
  completed_at TIMESTAMPTZ,
  notes TEXT,
  UNIQUE (execution_id, step_id)
);

CREATE TABLE sop_execution_photos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  execution_step_id UUID NOT NULL REFERENCES sop_execution_steps(id) ON DELETE CASCADE,
  storage_key TEXT NOT NULL,
  thumbnail_url TEXT,
  full_url TEXT,
  file_size_bytes BIGINT,
  captured_at TIMESTAMPTZ DEFAULT now(),
  gps_lat NUMERIC(10,7),
  gps_lng NUMERIC(10,7)
);


-- ═══════════════════════════════════════════════════════════════
-- 0006_reports_eyfs.sql — EYFS Child Development Reports
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE observations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
  teacher_id UUID NOT NULL REFERENCES profiles(id),
  class_id UUID REFERENCES classes(id),
  observation_date DATE NOT NULL DEFAULT CURRENT_DATE,
  note TEXT NOT NULL,
  eyfs_areas eyfs_area[] NOT NULL,
  media_urls TEXT[],
  linked_sop_execution_id UUID REFERENCES sop_executions(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_obs_child_date ON observations(child_id, observation_date DESC);
CREATE INDEX idx_obs_teacher ON observations(teacher_id);
-- GIN index for fast "find observations tagged X" queries
CREATE INDEX idx_obs_areas ON observations USING GIN (eyfs_areas);

-- Reports (generated every 4-6 weeks)
CREATE TABLE reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id UUID NOT NULL REFERENCES children(id) ON DELETE CASCADE,
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  status TEXT DEFAULT 'draft',  -- draft | sent | archived
  generated_by UUID REFERENCES profiles(id),
  generated_at TIMESTAMPTZ,
  sent_to_parent_at TIMESTAMPTZ,
  pdf_url TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE (child_id, period_start, period_end)
);

CREATE INDEX idx_reports_child ON reports(child_id, period_end DESC);

-- Report sections (observations / assessment / next steps)
CREATE TABLE report_sections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id UUID NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
  section_type TEXT NOT NULL,  -- 'observations' | 'assessment' | 'next_steps'
  body TEXT NOT NULL,
  display_order INT DEFAULT 0,
  UNIQUE (report_id, section_type)
);
