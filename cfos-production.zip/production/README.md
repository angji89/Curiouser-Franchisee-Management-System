# Curiouser Franchise Operating System (CFOS)

A production-ready, multi-tenant SaaS platform for franchise businesses in early years education.

**Stack:** Next.js 14 (App Router) · TypeScript · Tailwind CSS · Supabase (Auth, Postgres, Storage) · React Query · Zod

---

## Quick Start

```bash
# 1. Install dependencies
pnpm install

# 2. Set up Supabase locally
pnpm supabase:start          # boots Postgres + Auth + Storage on localhost
pnpm supabase:migrate        # applies migrations from db/migrations
pnpm db:seed                 # seed dev data (classes, courses, etc.)
pnpm supabase:types          # regenerate types/database.ts from your schema

# 3. Configure environment
cp .env.example .env.local   # then fill in values from `supabase status`

# 4. Run dev server
pnpm dev                     # → http://localhost:3000
```

---

## Architecture

### Core principles

1. **Multi-tenant isolation via Row-Level Security (RLS)** — every tenant-scoped table has RLS policies enforcing that users only see data for stores they belong to. Not application-layer filtering; database-enforced.
2. **Role-based access** — four roles (`HQ_ADMIN`, `FRANCHISEE_ADMIN`, `TEACHER`, `PARENT`) with clear permission matrices.
3. **Server-first data fetching** — React Server Components + Supabase SSR client. Client Components only for interactivity.
4. **Type safety end-to-end** — generated Supabase types + Zod schemas on API boundaries.

### Role matrix

| Role | Can see |
|---|---|
| `HQ_ADMIN` | All stores, all users, all data. Publishes curriculum and courses. |
| `FRANCHISEE_ADMIN` | Their own store(s). Manages teachers and children at their stores. |
| `TEACHER` | Only their assigned classes and children within their store. |
| `PARENT` | Only their own child's reports. |

### Folder structure

```
app/
├── (auth)/                    # Public routes — login, signup, forgot password
│   └── login/page.tsx
├── (dashboard)/               # Authenticated app — middleware-protected
│   ├── layout.tsx             # Dashboard shell (sidebar, header)
│   ├── dashboard/page.tsx     # Home
│   ├── classes/               # Class Plans module
│   ├── training/              # Training Academy module
│   ├── sop/                   # SOP Execution module
│   ├── reports/               # EYFS Child Reports module
│   └── admin/                 # HQ_ADMIN + FRANCHISEE_ADMIN only
│       ├── users/page.tsx
│       └── stores/page.tsx
├── api/                       # Route handlers (REST endpoints)
│   ├── users/route.ts
│   ├── stores/route.ts
│   ├── observations/route.ts
│   └── reports/route.ts
└── middleware.ts              # Auth + role-based route gating

lib/
├── supabase/
│   ├── server.ts              # Server Component client (cookie-aware)
│   ├── client.ts              # Browser client
│   └── middleware.ts          # Middleware client (refreshes session)
├── auth/
│   ├── get-user.ts            # getUser() with role enrichment
│   └── require-role.ts        # requireRole() helper for server components
├── api/
│   ├── query-client.ts        # React Query provider
│   └── queries/               # Reusable query hooks
│       ├── users.ts
│       ├── stores.ts
│       ├── observations.ts
│       └── ...
└── utils.ts                   # cn() + helpers

components/
├── ui/                        # Primitives — Button, Input, Card, Dialog...
├── layout/                    # AppShell, TopNav, SideNav, MobileNav
└── modules/                   # Feature-scoped components
    ├── classes/
    ├── training/
    ├── sop/
    └── reports/

db/
├── migrations/                # SQL migration files (applied in order)
│   ├── 0001_enums.sql
│   ├── 0002_core_tenants.sql
│   ├── 0003_class_plans.sql
│   ├── 0004_training.sql
│   ├── 0005_sops.sql
│   ├── 0006_reports_eyfs.sql
│   └── 0007_rls_policies.sql
└── seed/                      # TypeScript seed scripts
    └── index.ts

types/
├── database.ts                # Generated from Supabase schema
├── roles.ts                   # Role enum + permissions matrix
└── domain.ts                  # Domain types (EYFS areas, etc.)
```

---

## Environment variables (`.env.local`)

```bash
# Supabase
NEXT_PUBLIC_SUPABASE_URL=http://localhost:54321
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...    # server-only; never expose

# App
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

---

## Database migrations

Migrations live in `db/migrations/` and are applied via `supabase db push`. They are numbered `0001_`, `0002_`, etc., and **must be applied in order** because later files reference earlier ones.

To add a new migration: create `db/migrations/0008_your_change.sql` and run `pnpm supabase:migrate`.

---

## Testing the role system locally

After `pnpm db:seed`, you'll have these test users (password `curiouser123` for all):

| Email | Role | Store |
|---|---|---|
| `hq@curiouser.co` | HQ_ADMIN | — |
| `sarah@curiouser.co` | FRANCHISEE_ADMIN | Selangor Central |
| `james@curiouser.co` | FRANCHISEE_ADMIN | KL Bangsar |
| `maya@curiouser.co` | TEACHER | Selangor Central |
| `daniel@curiouser.co` | TEACHER | Selangor Central |

Log in as each to verify RLS is working: `sarah` should see only Selangor Central data, `maya` should see only her assigned classes, etc.

---

## What's implemented in v1

- ✅ Authentication (email + password)
- ✅ Multi-tenant schema with RLS
- ✅ Role-based middleware
- ✅ User + store management
- ✅ Class Plans library (IP-protected)
- ✅ Training Academy (courses, progress, quizzes, certificates)
- ✅ SOP Execution (mobile checklists with photo proof)
- ✅ EYFS observations + child reports

## What's next (v2 roadmap)

- Parent portal (PARENT role UI)
- HQ analytics dashboards
- Mobile app (React Native, shared API)
- Offline SOP execution with sync
- Multilingual curriculum (EN / BM / ZH)
- Real-time collaboration on observations
