import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import type { AppRole } from '@/types/roles';

/**
 * Authenticated user with enriched profile data (role, store memberships).
 * Returned by `getUser()` and `requireUser()` for use in Server Components.
 */
export type AuthedUser = {
  id: string;
  email: string;
  fullName: string;
  avatarUrl: string | null;
  role: AppRole;
  storeIds: string[];
  storeMemberships: Array<{
    storeId: string;
    roleAtStore: AppRole;
    isPrimary: boolean;
  }>;
};

/**
 * Returns the current user with their profile + store memberships, or null.
 * Use in Server Components that need user context but shouldn't force a login.
 */
export async function getUser(): Promise<AuthedUser | null> {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const [{ data: profile }, { data: memberships }] = await Promise.all([
    supabase
      .from('profiles')
      .select('id, email, full_name, avatar_url, role')
      .eq('id', user.id)
      .single(),
    supabase
      .from('user_store_relationship')
      .select('store_id, role_at_store, is_primary')
      .eq('user_id', user.id),
  ]);

  if (!profile) return null;

  return {
    id: profile.id,
    email: profile.email,
    fullName: profile.full_name,
    avatarUrl: profile.avatar_url,
    role: profile.role as AppRole,
    storeIds: (memberships ?? []).map((m) => m.store_id),
    storeMemberships: (memberships ?? []).map((m) => ({
      storeId: m.store_id,
      roleAtStore: m.role_at_store as AppRole,
      isPrimary: m.is_primary ?? false,
    })),
  };
}

/**
 * Requires an authenticated user. Redirects to /login if none.
 */
export async function requireUser(): Promise<AuthedUser> {
  const user = await getUser();
  if (!user) redirect('/login');
  return user;
}

/**
 * Requires the user to have one of the given roles. Redirects otherwise.
 *   const user = await requireRole(['HQ_ADMIN', 'FRANCHISEE_ADMIN']);
 */
export async function requireRole(allowed: AppRole[]): Promise<AuthedUser> {
  const user = await requireUser();
  if (!allowed.includes(user.role)) {
    redirect('/dashboard?error=forbidden');
  }
  return user;
}
