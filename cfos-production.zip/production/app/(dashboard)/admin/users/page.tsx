import { requireRole } from '@/lib/auth/get-user';
import { createClient } from '@/lib/supabase/server';

/**
 * Admin → Users.
 * Only HQ_ADMIN and FRANCHISEE_ADMIN reach here (middleware + requireRole).
 * RLS scopes the users they can see.
 */
export default async function AdminUsersPage() {
  const caller = await requireRole(['HQ_ADMIN', 'FRANCHISEE_ADMIN']);
  const supabase = createClient();

  const { data: users } = await supabase
    .from('profiles')
    .select('id, email, full_name, role, is_active, created_at')
    .order('created_at', { ascending: false });

  return (
    <div className="max-w-[1200px] mx-auto px-5 md:px-8 py-12 md:py-16">
      <div className="mb-12">
        <div
          className="text-[11px] text-[#7a7066] uppercase mb-4 font-medium"
          style={{ letterSpacing: '0.16em' }}
        >
          Administration
        </div>
        <h1
          className="text-[40px] md:text-[56px] font-medium text-[#2a3538] mb-4"
          style={{ letterSpacing: '-0.04em', lineHeight: 1.02 }}
        >
          User management.
        </h1>
        <p className="text-[16px] text-[#7a7066] max-w-xl">
          {caller.role === 'HQ_ADMIN'
            ? 'All users across every franchise.'
            : 'Users at your franchise locations.'}
        </p>
      </div>

      <div className="bg-[#fdfbf6] rounded-2xl border border-[#e6ddd0] overflow-hidden">
        <div className="bg-[#faf6ef] border-b border-[#e6ddd0] px-5 py-3 grid grid-cols-12 gap-4 text-[11px] uppercase text-[#a89f92] font-medium"
             style={{ letterSpacing: '0.14em' }}>
          <div className="col-span-4">User</div>
          <div className="col-span-3">Role</div>
          <div className="col-span-3">Joined</div>
          <div className="col-span-2 text-right">Status</div>
        </div>
        {(users ?? []).map((u, i, arr) => (
          <div
            key={u.id}
            className={`px-5 py-4 grid grid-cols-12 gap-4 items-center ${
              i !== arr.length - 1 ? 'border-b border-[#e6ddd0]' : ''
            }`}
          >
            <div className="col-span-4 min-w-0">
              <div className="text-[14px] font-medium text-[#2a3538] truncate">{u.full_name}</div>
              <div className="text-[11px] text-[#7a7066] truncate">{u.email}</div>
            </div>
            <div className="col-span-3 text-[13px] text-[#2a3538]">{u.role.replace('_', ' ')}</div>
            <div className="col-span-3 text-[12px] text-[#7a7066] tabular-nums">
              {new Date(u.created_at ?? '').toLocaleDateString()}
            </div>
            <div className="col-span-2 text-right">
              <span
                className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium ${
                  u.is_active
                    ? 'bg-[#5f7a4a]/10 text-[#5f7a4a]'
                    : 'bg-[#faf6ef] text-[#7a7066] border border-[#e6ddd0]'
                }`}
              >
                {u.is_active ? 'Active' : 'Inactive'}
              </span>
            </div>
          </div>
        ))}
        {(!users || users.length === 0) && (
          <div className="px-5 py-12 text-center text-[13px] text-[#7a7066]">No users yet.</div>
        )}
      </div>
    </div>
  );
}
