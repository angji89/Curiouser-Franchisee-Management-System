import { requireUser } from '@/lib/auth/get-user';
import { createClient } from '@/lib/supabase/server';
import { ROLE_LABELS } from '@/types/roles';

export default async function DashboardPage() {
  const user = await requireUser();
  const supabase = createClient();

  // Example: fetch today's session count (RLS-scoped automatically)
  const today = new Date().toISOString().slice(0, 10);
  const [{ count: sopCount }, { count: obsCount }] = await Promise.all([
    supabase
      .from('sop_executions')
      .select('*', { count: 'exact', head: true })
      .eq('session_date', today),
    supabase
      .from('observations')
      .select('*', { count: 'exact', head: true })
      .gte('observation_date', today),
  ]);

  return (
    <div className="max-w-[1200px] mx-auto px-5 md:px-8 py-12 md:py-20">
      <div className="mb-16">
        <div
          className="text-[11px] text-[#7a7066] uppercase mb-6 font-medium"
          style={{ letterSpacing: '0.16em' }}
        >
          {new Date().toLocaleDateString('en-US', { weekday: 'long', day: 'numeric', month: 'long' })}
        </div>
        <h1
          className="text-[44px] md:text-[88px] font-medium text-[#2a3538] leading-[1.01]"
          style={{ letterSpacing: '-0.04em' }}
        >
          Good morning, {user.fullName.split(' ')[0]}.
        </h1>
        <p
          className="text-[22px] md:text-[36px] text-[#7a7066] leading-[1.25] mt-4 max-w-3xl"
          style={{ fontFamily: 'Instrument Serif, Georgia, serif' }}
        >
          Signed in as <em>{ROLE_LABELS[user.role]}</em>.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-[#e6ddd0] rounded-2xl overflow-hidden">
        <StatTile value={String(sopCount ?? 0)} label="SOPs today" />
        <StatTile value={String(obsCount ?? 0)} label="Observations today" />
        <StatTile value={String(user.storeIds.length)} label="Your stores" />
        <StatTile value="—" label="Reports due" />
      </div>
    </div>
  );
}

function StatTile({ value, label }: { value: string; label: string }) {
  return (
    <div className="bg-[#f7f2eb] p-6 md:p-8">
      <div
        className="text-[36px] md:text-[52px] font-medium text-[#2a3538] mb-1"
        style={{ letterSpacing: '-0.04em', lineHeight: 1.01 }}
      >
        {value}
      </div>
      <div className="text-[12px] text-[#7a7066]">{label}</div>
    </div>
  );
}
