'use client';

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export default function LoginPage() {
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get('next') ?? '/dashboard';

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const supabase = createClient();
    const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });

    if (signInError) {
      setError(signInError.message);
      setLoading(false);
      return;
    }

    router.push(next);
    router.refresh();
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#f7f2eb] px-5">
      <div className="w-full max-w-sm">
        <div className="mb-10 text-center">
          <div className="inline-flex items-center gap-2.5 mb-8">
            <div className="w-10 h-10 rounded-lg bg-[#2a3538] flex items-center justify-center">
              <span className="font-serif italic text-[#fdfbf6] text-[22px] leading-none">C</span>
            </div>
          </div>
          <h1 className="text-[32px] font-medium text-[#2a3538] mb-2" style={{ letterSpacing: '-0.03em' }}>
            Welcome back.
          </h1>
          <p className="text-[14px] text-[#7a7066]">Sign in to your Curiouser workspace.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-[11px] tracked text-[#a89f92] uppercase font-medium block mb-1.5" style={{ letterSpacing: '0.14em' }}>
              Email
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#d4c8b5] bg-[#fdfbf6] text-[14px] focus:border-[#3f4d51] focus:outline-none focus:ring-2 focus:ring-[#3f4d51]/10"
              placeholder="you@curiouser.co"
            />
          </div>

          <div>
            <label className="text-[11px] tracked text-[#a89f92] uppercase font-medium block mb-1.5" style={{ letterSpacing: '0.14em' }}>
              Password
            </label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#d4c8b5] bg-[#fdfbf6] text-[14px] focus:border-[#3f4d51] focus:outline-none focus:ring-2 focus:ring-[#3f4d51]/10"
              placeholder="••••••••"
            />
          </div>

          {error && (
            <div className="text-[13px] text-[#a33a29] bg-[#a33a29]/5 border border-[#a33a29]/20 px-3 py-2 rounded-lg">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-full bg-[#2a3538] text-[#fdfbf6] font-medium text-[13px] hover:bg-[#1a2427] transition disabled:opacity-40"
          >
            {loading ? 'Signing in…' : 'Sign in'}
          </button>

          <div className="text-center text-[12px] text-[#7a7066] pt-2">
            <a href="/forgot-password" className="hover:text-[#3f4d51] transition">
              Forgot password?
            </a>
          </div>
        </form>
      </div>
    </div>
  );
}
