import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createClient, createServiceClient } from '@/lib/supabase/server';
import { requireRole } from '@/lib/auth/get-user';

const CreateUserSchema = z.object({
  email: z.string().email(),
  fullName: z.string().min(1).max(120),
  role: z.enum(['HQ_ADMIN', 'FRANCHISEE_ADMIN', 'TEACHER', 'PARENT']),
  storeId: z.string().uuid().optional(),
});

// ─── GET /api/users — list users (scoped by RLS) ─────────────
export async function GET(request: Request) {
  await requireRole(['HQ_ADMIN', 'FRANCHISEE_ADMIN']);

  const supabase = createClient();
  const { searchParams } = new URL(request.url);
  const storeId = searchParams.get('storeId');

  let query = supabase
    .from('profiles')
    .select('id, email, full_name, role, is_active, created_at')
    .order('created_at', { ascending: false });

  if (storeId) {
    const { data: memberships } = await supabase
      .from('user_store_relationship')
      .select('user_id')
      .eq('store_id', storeId);
    query = query.in('id', (memberships ?? []).map((m) => m.user_id));
  }

  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ users: data });
}

// ─── POST /api/users — invite a new user ─────────────────────
// Uses the service client because creating auth.users requires elevated privilege.
// We still gate access via requireRole().
export async function POST(request: Request) {
  const caller = await requireRole(['HQ_ADMIN', 'FRANCHISEE_ADMIN']);

  const body = await request.json();
  const parsed = CreateUserSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  const { email, fullName, role, storeId } = parsed.data;

  // FRANCHISEE_ADMIN can only assign users to their own stores
  if (caller.role === 'FRANCHISEE_ADMIN') {
    if (role === 'HQ_ADMIN') {
      return NextResponse.json({ error: 'Cannot create HQ Admin' }, { status: 403 });
    }
    if (storeId && !caller.storeIds.includes(storeId)) {
      return NextResponse.json({ error: 'Cannot assign user to another franchise' }, { status: 403 });
    }
  }

  const admin = createServiceClient();

  // 1. Create auth user (the profile row is auto-created via trigger)
  const { data: created, error: createErr } = await admin.auth.admin.inviteUserByEmail(email, {
    data: { full_name: fullName, role },
  });

  if (createErr || !created.user) {
    return NextResponse.json({ error: createErr?.message ?? 'Failed to create user' }, { status: 500 });
  }

  // 2. Link to store (if provided)
  if (storeId) {
    const { error: linkErr } = await admin.from('user_store_relationship').insert({
      user_id:       created.user.id,
      store_id:      storeId,
      role_at_store: role,
      assigned_by:   caller.id,
      is_primary:    true,
    });
    if (linkErr) {
      return NextResponse.json({ error: `User created but store link failed: ${linkErr.message}` }, { status: 500 });
    }
  }

  return NextResponse.json({ userId: created.user.id }, { status: 201 });
}
