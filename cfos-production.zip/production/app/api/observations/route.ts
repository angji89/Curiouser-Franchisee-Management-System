import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createClient } from '@/lib/supabase/server';
import { requireUser } from '@/lib/auth/get-user';

const EYFS_AREAS = [
  'communication_language',
  'physical_development',
  'personal_social_emotional',
  'literacy',
  'mathematics',
  'understanding_world',
  'expressive_arts_design',
] as const;

const CreateObservationSchema = z.object({
  childId: z.string().uuid(),
  note: z.string().min(10).max(4000),
  eyfsAreas: z.array(z.enum(EYFS_AREAS)).min(1).max(7),
  observationDate: z.string().optional(),  // ISO date; defaults to today
  mediaUrls: z.array(z.string().url()).optional(),
});

// ─── GET /api/observations?childId=... ───────────────────────
// Lists observations. RLS scopes the results to what the caller can see.
export async function GET(request: Request) {
  await requireUser();

  const supabase = createClient();
  const { searchParams } = new URL(request.url);
  const childId = searchParams.get('childId');

  let query = supabase
    .from('observations')
    .select('id, child_id, teacher_id, note, eyfs_areas, observation_date, media_urls, created_at')
    .order('observation_date', { ascending: false });

  if (childId) query = query.eq('child_id', childId);

  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ observations: data });
}

// ─── POST /api/observations — create an observation ──────────
// RLS enforces: TEACHER can only create for children in their assigned classes.
export async function POST(request: Request) {
  const user = await requireUser();

  const body = await request.json();
  const parsed = CreateObservationSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  const { childId, note, eyfsAreas, observationDate, mediaUrls } = parsed.data;

  const supabase = createClient();
  const { data, error } = await supabase
    .from('observations')
    .insert({
      child_id:         childId,
      teacher_id:       user.id,
      note,
      eyfs_areas:       eyfsAreas,
      observation_date: observationDate ?? new Date().toISOString().slice(0, 10),
      media_urls:       mediaUrls ?? [],
    })
    .select()
    .single();

  if (error) {
    // RLS denial returns a permission error — surface it nicely
    if (error.code === '42501' || error.message.includes('row-level security')) {
      return NextResponse.json({ error: 'You do not have permission to create observations for this child' }, { status: 403 });
    }
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ observation: data }, { status: 201 });
}
