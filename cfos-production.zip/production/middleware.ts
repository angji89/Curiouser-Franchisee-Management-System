import { NextResponse, type NextRequest } from 'next/server';
import { updateSession } from '@/lib/supabase/middleware';
import { getRequiredRoles } from '@/types/roles';

/**
 * Routes that don't require authentication.
 */
const PUBLIC_PATHS = ['/login', '/signup', '/forgot-password', '/auth/callback'];

const isPublic = (pathname: string) =>
  PUBLIC_PATHS.some((p) => pathname === p || pathname.startsWith(p + '/'));

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Refresh the Supabase session on every request (even public ones)
  const { response, supabase, user } = await updateSession(request);

  // ─── Public paths ─────────────────────────────────────────
  if (isPublic(pathname)) {
    // If they're already signed in, bounce them to the dashboard
    if (user && pathname === '/login') {
      return NextResponse.redirect(new URL('/dashboard', request.url));
    }
    return response;
  }

  // ─── Protected paths: require auth ─────────────────────────
  if (!user) {
    const redirectTo = new URL('/login', request.url);
    redirectTo.searchParams.set('next', pathname);
    return NextResponse.redirect(redirectTo);
  }

  // ─── Role-based gating ────────────────────────────────────
  const required = getRequiredRoles(pathname);
  if (required) {
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    if (!profile || !required.includes(profile.role as never)) {
      return NextResponse.redirect(new URL('/dashboard?error=forbidden', request.url));
    }
  }

  return response;
}

export const config = {
  // Run middleware on everything except static assets and Next internals
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico)$).*)',
  ],
};
