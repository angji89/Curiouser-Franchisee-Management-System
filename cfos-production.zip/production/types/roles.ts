/**
 * Application roles — must mirror the `app_role` enum in Supabase.
 */
export const APP_ROLES = ['HQ_ADMIN', 'FRANCHISEE_ADMIN', 'TEACHER', 'PARENT'] as const;
export type AppRole = (typeof APP_ROLES)[number];

/**
 * Human-readable labels for UI.
 */
export const ROLE_LABELS: Record<AppRole, string> = {
  HQ_ADMIN:         'HQ Admin',
  FRANCHISEE_ADMIN: 'Franchisee',
  TEACHER:          'Teacher',
  PARENT:           'Parent',
};

/**
 * Permission matrix — used for route gating in middleware and UI gating in pages.
 * Keep this in sync with the RLS policies in 0007_rls_policies.sql.
 */
export const ROLE_PERMISSIONS = {
  HQ_ADMIN: {
    canManageAllStores: true,
    canManageAllUsers:  true,
    canPublishCurriculum: true,
    canPublishCourses:  true,
    canViewAllReports:  true,
    canAccessAdmin:     true,
  },
  FRANCHISEE_ADMIN: {
    canManageAllStores: false,
    canManageOwnStores: true,
    canManageOwnStoreUsers: true,
    canViewOwnStoreReports: true,
    canAccessAdmin: true,  // but scoped — middleware enforces
  },
  TEACHER: {
    canCreateObservations: true,
    canExecuteSOPs: true,
    canViewAssignedClasses: true,
    canCompleteTrainings: true,
    canAccessAdmin: false,
  },
  PARENT: {
    canViewOwnChildReports: true,
    canAccessAdmin: false,
  },
} as const;

/**
 * Route-level access control.
 * Used by `middleware.ts` to gate paths before they render.
 */
export const ROUTE_ROLES: Record<string, AppRole[]> = {
  '/admin':           ['HQ_ADMIN', 'FRANCHISEE_ADMIN'],
  '/admin/users':     ['HQ_ADMIN', 'FRANCHISEE_ADMIN'],
  '/admin/stores':    ['HQ_ADMIN'],
  '/classes':         ['HQ_ADMIN', 'FRANCHISEE_ADMIN', 'TEACHER'],
  '/training':        ['HQ_ADMIN', 'FRANCHISEE_ADMIN', 'TEACHER'],
  '/sop':             ['HQ_ADMIN', 'FRANCHISEE_ADMIN', 'TEACHER'],
  '/reports':         ['HQ_ADMIN', 'FRANCHISEE_ADMIN', 'TEACHER', 'PARENT'],
};

/**
 * Resolve the minimum required roles for a given path.
 * Longest matching prefix wins.
 */
export function getRequiredRoles(pathname: string): AppRole[] | null {
  const matches = Object.entries(ROUTE_ROLES)
    .filter(([prefix]) => pathname.startsWith(prefix))
    .sort((a, b) => b[0].length - a[0].length);
  return matches[0]?.[1] ?? null;
}
