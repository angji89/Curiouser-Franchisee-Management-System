import type { Config } from 'tailwindcss';

export default {
  content: [
    './app/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './lib/**/*.{ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        paper:   '#f7f2eb',
        cream:   '#faf6ef',
        canvas:  '#fdfbf6',
        line:    '#e6ddd0',
        line2:   '#d4c8b5',
        ink:     '#3f4d51',
        ink2:    '#2a3538',
        muted:   '#7a7066',
        muted2:  '#a89f92',
        ochre:   '#c98b2c',
        ochre2:  '#a67321',
        coral:   '#bf5f49',
        slate:   '#5c707a',
        success: '#5f7a4a',
        warning: '#b25000',
        danger:  '#a33a29',
      },
      fontFamily: {
        sans:    ['var(--font-inter)',            'system-ui', 'sans-serif'],
        display: ['var(--font-instrument-serif)', 'Georgia',   'serif'],
      },
    },
  },
  plugins: [],
} satisfies Config;
