'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { useRouter } from 'next/navigation';
import type { AuthedUser } from '@/lib/auth/get-user';
import { clsx } from 'clsx';

const NAV = [
  { href: '/dashboard',  label: 'Dashboard',   roles: ['HQ_ADMIN', 'FRANCHISEE_ADMIN', 'TEACHER', 'PARENT'] },
  { href: '/classes',    label: 'Class Plans', roles: ['HQ_ADMIN', 'FRANCHISEE_ADMIN', 'TEACHER'] },
  { href: '/training',   label: 'Training',    roles: ['HQ_ADMIN', 'FRANCHISEE_ADMIN', 'TEACHER'] },
  { href: '/sop',        label: 'SOP',         roles: ['HQ_ADMIN', 'FRANCHISEE_ADMIN', 'TEACHER'] },
  { href: '/reports',    label: 'Reports',     roles: ['HQ_ADMIN', 'FRANCHISEE_ADMIN', 'TEACHER', 'PARENT'] },
  { href: '/admin',      label: 'Admin',       roles: ['HQ_ADMIN', 'FRANCHISEE_ADMIN'] },
];

export function AppShell({ user, children }: { user: AuthedUser; children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();

  const nav = NAV.filter((item) => item.roles.includes(user.role));
  const initials = user.fullName.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase();

  const handleSignOut = async () => {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push('/login');
    router.refresh();
  };

  return (
    <div className="min-h-screen bg-[#f7f2eb]">
      <header className="sticky top-0 z-40 bg-[#f7f2eb]/80 backdrop-blur-xl border-b border-[#e6ddd0]">
        <div className="max-w-[1440px] mx-auto px-5 md:px-8 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/dashboard" className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-md bg-[#2a3538] flex items-center justify-center">
                <span
                  className="text-[#fdfbf6] text-[16px] leading-none"
                  style={{ fontFamily: 'Instrument Serif, Georgia, serif' }}
                >
                  C
                </span>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-[15px] font-medium text-[#2a3538]" style={{ letterSpacing: '-0.02em' }}>
                  Curiouser
                </span>
                <span
                  className="text-[10.5px] text-[#a89f92] uppercase font-medium"
                  style={{ letterSpacing: '0.16em' }}
                >
                  CFOS
                </span>
              </div>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-0.5">
            {nav.map((item) => {
              const active = pathname.startsWith(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={clsx(
                    'px-3 py-1.5 rounded-md text-[13px] font-medium transition',
                    active ? 'bg-[#faf6ef] text-[#2a3538]' : 'text-[#7a7066] hover:text-[#2a3538]'
                  )}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-3">
            <div className="hidden md:block text-right">
              <div className="text-[12.5px] font-medium text-[#2a3538]">{user.fullName}</div>
              <div className="text-[10.5px] text-[#7a7066]">
                {user.role.replace('_', ' ')}
                {user.storeIds.length > 0 && ` · ${user.storeIds.length} store${user.storeIds.length > 1 ? 's' : ''}`}
              </div>
            </div>
            <div className="w-8 h-8 rounded-full bg-[#2a3538] text-[#fdfbf6] flex items-center justify-center text-[10.5px] font-medium">
              {initials}
            </div>
            <button
              onClick={handleSignOut}
              className="text-[12px] text-[#7a7066] hover:text-[#2a3538] transition"
            >
              Sign out
            </button>
          </div>
        </div>
      </header>

      <main>{children}</main>
    </div>
  );
}
